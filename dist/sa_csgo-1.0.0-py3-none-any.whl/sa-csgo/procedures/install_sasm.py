from addons.gui import Procedure


class CustomProcedure(Procedure):
    id=6
    name = "Install SA:SM  (Coming Soon)"
    description= "Latest version of Storm Agent : Source Mod"

    def run():
        pass